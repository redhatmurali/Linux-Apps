﻿==============================================
              OTRS OPC v3.0.1b
        Version 3.0.1b, August 15, 2021
              http://ip-lab.ru/
==============================================

OTRS Asterisk Integration Module (PBX Integration Module).

==============================================
                  License
==============================================

Package OPC v3.0.1b is distributed under license AGPL-3.0.

==============================================
            License agreement
==============================================

This software and all files accompanying it are provided by the Author by the principle "as is", without any obvious or implied 
guarantees, including (but without being limited to it) implied guarantees of commodity suitability and compliance for any mission. 
Under no circumstances neither the Author of the software, nor the Author of localization bears responsibility for any damages (including losses of profit, 
damage of data, business interruption, loss of business information and any other financial losses), arisen owing to correct or wrong 
uses of this software product even if it was in advance known of a possibility of such damages. 
All responsibility for use of this program and documentation lies only on you.
Information in this document can be changed without notice and obligations from the Author. 
On described here the software this License agreement extends.
Use of this product during any period of time means that you accept all conditions of this License agreement.
You can find more detailed information in GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPL-3.0)
http://www.gnu.org/licenses/agpl-3.0.ru.html

==============================================
             Installation notes
==============================================


The OPC v3.0.1b package uses additional perl-libraries which are required to be established:
AnyEvent 
IO::Socket::Timeout

Installation on Ubuntu
For installation of additional Perl modules execute command:
sudo apt-get install -y libplack-test-anyevent-perl libio-socket-timeout-perl
The specified modules will be installed.

To install additional perl-libraries on CentOS, execute command:
yum install perl-AnyEvent
yum install perl-IO-Socket-Timeout

To install additional perl-libraries on FreeBSD, execute command:
cpan AnyEvent
cpan IO::Socket::Timeout

Install the package OPC v3.0.1b via OTRS "Package Manager" menu.

Restart the CRON service by running:
/opt/otrs/bin/Cron.sh restart otrs

The package was tested with the servers Asterisk v13.1.0, v14.6.2, v15.4.0. 
On the Asterisk server, create a user to connect to the AMI interface:

For general Asterisk versions:
Open the manager.conf file for editing
nano /etc/asterisk/manager.conf
Add the following lines:

[otrs]
secret = SomePassword
deny=0.0.0.0/0.0.0.0
permit=IP_address_OTRS/255.255.255.255
read = system,call
write = system
writetimeout = 100

For some versions of Asterisk (13.1.x):
Create the otrs.conf file in the directory /etc/asterisk/manager.d/:
nano /etc/asterisk/manager.d/otrs.conf
Add the following lines:

[otrs]
secret = SomePassword
deny=0.0.0.0/0.0.0.0
permit=IP_address_OTRS/255.255.255.255
read = system,call
write = system
writetimeout = 100

After making the changes, restart Asterisk using the CLI: 
asterisk -r
by executing the command:
core restart gracefully

Further configuration is done through the OTRS web interface.
The settings are on the Administration-> Block "Communication & Notifications" -> Call Notification.


==============================================
           Uninstall package OPC v3.0.1b
==============================================

After uninstall of the package through the OTRS menu "Package Manager", the database remains in the system and require manual removal.
This is done so that would be your information will not be accidentally deleted when reinstalling the package.
If the use of OPC v3.0.1b package in the future is not planned or necessary to carry out a fresh clean install, remove the database tables:
OPC v3.0.1b module uses the following 6 tables:
pim_modifier_list
pim_pbx_agents
pim_pbx_did
pim_pbx_table
pim_ticket_template
pim_pbx_link 
pim_cid_category
The tables are in the database otrs

To delete the table, use the following queries:
1. Connect to the MySQL server
mysql -u root -p
>your_password_for_root
2. Change the database to otrs:
USE otrs;
3. Delete the table by running the query:
DROP TABLE IF EXISTS pim_modifier_list, pim_pbx_agents, pim_pbx_did, pim_pbx_table, pim_ticket_template, pim_pbx_link, pim_cid_category;
4. Disconnect from the MySQL server:
QUIT

==============================================
                Feedback
==============================================
If you have any suggestions, comments on the modules or you have found a errors in the OPC v3.0.1b package,
please write to us at e-mail listed on the website under http://ip-lab.ru/ "Contact Us".
